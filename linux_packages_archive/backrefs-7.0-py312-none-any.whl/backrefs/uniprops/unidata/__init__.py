"""Unicode Properties from Unicode version 15.0.0 (autogen)."""
